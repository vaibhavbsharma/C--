int main()
{
/* 1: this is just a sample */
int n;
int abc, def;
struct new {
int a1;
float b1;
} s1;
write("Enter a number");
/* 2: this is a 3-line
comment
*/
n = read();
abc = n + 1;
def = abc * abc;
write(def); /* 3: this is /* the end ***/
}

